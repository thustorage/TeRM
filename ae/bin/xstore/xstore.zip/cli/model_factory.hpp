#pragma once

#include "model_fetcher.hpp"

namespace fstore {

/*!
  A wrapper over the model fetcher, which fetches the model using one thread
 */
class ModelFactory {
 public:

}; // model factory

} // fstore
