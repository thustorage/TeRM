#pragma once

namespace fstore {

class Scanner {
 public:

};

}
