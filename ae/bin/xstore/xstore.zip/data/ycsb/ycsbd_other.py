from ycsbd import *

data = data1

ylim = 1.0

ylabel = "Ratio"

legends = legends1
