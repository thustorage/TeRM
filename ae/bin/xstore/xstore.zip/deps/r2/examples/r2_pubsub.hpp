#pragma once
#include "../deps/r2/src/msg/protocol.hpp"

namespace r2{
    class 
}