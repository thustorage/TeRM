#pragma once

namespace r2 {

const int global_mr_id = 73;

} // end namespace
