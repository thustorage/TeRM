#pragma once
#include <cinttypes>

namespace r2 {
const u64 GB = 1 << 30;
const u64 MB = 1 << 20;
const u64 KB = 1 << 10;
} // namespace r2
