#pragma once

namespace  rdmaio {

enum {
  TCP_PORT = 8888,
  GLOBAL_MR_ID = 73
};

}
