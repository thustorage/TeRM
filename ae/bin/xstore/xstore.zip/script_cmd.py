./bootstrap_client.py -c s -cc 16 -w sc_rdma -t 12  -sa "-ycsb_num 10000000" -ca='-total_accts=10000000' -e 20
