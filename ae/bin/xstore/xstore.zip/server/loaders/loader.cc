#include <gflags/gflags.h>

namespace fstore {

namespace server {

DEFINE_int64(ycsb_num,10000,"Num of accounts loaded for YCSB.");

} // server

} // fstore
