#pragma once

#include "common.hpp"
#include "datastream/stream.hpp"

namespace fstore {

namespace sources {

namespace  osm {




} // osm

} // sources

} // fstore
