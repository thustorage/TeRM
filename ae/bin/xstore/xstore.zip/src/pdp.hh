#pragma once

// sys
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>

// c++
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <string>
#include <optional>
#include <source_location>
#include <cstdio>

#define COLOR_BLACK         "\033[0;30m"
#define COLOR_RED           "\033[0;31m"
#define COLOR_GREEN         "\033[0;32m"
#define COLOR_YELLOW        "\033[0;33m"
#define COLOR_BLUE          "\033[0;34m"
#define COLOR_MAGENTA       "\033[0;35m"
#define COLOR_CYAN          "\033[0;36m"
#define COLOR_WHITE         "\033[0;37m"
#define COLOR_DEFAULT       "\033[0;39m"

#define COLOR_BOLD_BLACK    "\033[1;30m"
#define COLOR_BOLD_RED      "\033[1;31m"
#define COLOR_BOLD_GREEN    "\033[1;32m"
#define COLOR_BOLD_YELLOW   "\033[1;33m"
#define COLOR_BOLD_BLUE     "\033[1;34m"
#define COLOR_BOLD_MAGENTA  "\033[1;35m"
#define COLOR_BOLD_CYAN     "\033[1;36m"
#define COLOR_BOLD_WHITE    "\033[1;37m"
#define COLOR_BOLD_DEFAULT  "\033[1;39m"

#define PT_RESET            "\033[0m"
#define PT_BOLD             "\033[1m"
#define PT_UNDERLINE        "\033[4m"
#define PT_BLINKING         "\033[5m"
#define PT_INVERSE          "\033[7m"

#define LIBPDP_PREFIX COLOR_CYAN "[libpdp] " PT_RESET
#define pr_libpdp(fmt, args...) printf(LIBPDP_PREFIX fmt "\n", ##args)

#define EXTRACT_FILENAME(PATH) (__builtin_strrchr("/" PATH, '/') + 1)
#define __FILENAME__ EXTRACT_FILENAME(__FILE__)

#define pr(fmt, args...)  pr_libpdp(COLOR_GREEN "%s:%d: %s:" PT_RESET " (tid=%d) " fmt, __FILENAME__, __LINE__, __func__, gettid(), ##args)
#define pr_flf(file, line, func, fmt, args...) pr_libpdp(COLOR_GREEN "%s:%d: %s:" PT_RESET " (tid=%d) " fmt, file, line, func, gettid(), ##args)

#define pr_info(fmt, args...) pr(fmt, ##args)
#define pr_err(fmt, args...)  pr(COLOR_RED fmt PT_RESET, ##args)
#define pr_warn(fmt, args...) pr(COLOR_MAGENTA fmt PT_RESET, ##args)
#define pr_emph(fmt, args...) pr(COLOR_YELLOW fmt PT_RESET, ##args)

#define pr_once(level, format...)	({	\
	static bool __warned = false;			\
    if (!__warned) [[unlikely]] { pr_##level(format); 	\
    __warned = true;}		\
})

// #define ASSERT(...)
#define PDP_ASSERT(cond, format, args...)  ({ \
    if (!(cond)) [[unlikely]] { \
    pr_err(format, ##args); \
    exit(EXIT_FAILURE); \
    } \
})

#ifndef SZ_4K
#define SZ_4K (4ul << 10)
#endif
#ifndef SZ_1G
#define SZ_1G (1ul << 30)
#endif

namespace pdp {
    auto round_up(auto a, auto b)
    {
        return (a + b - 1) / b * b;
    }

    static inline std::optional<std::string> getenv_string(const char *env)
    {
        const char *v = getenv(env);
        if (!v) {
            return std::nullopt;
        }
        return std::string(v);
    }

    static bool check_call_once()
    {
        static bool inited = false;
        PDP_ASSERT(!inited, "can alloc only once!");
        inited = true;
        return inited;
    }

    void *alloc(size_t size)
    {
        // return calloc(1, size);
        static bool inited = check_call_once();
        (void)inited;

        auto dev = getenv_string("PDP_server_mmap_dev");
        PDP_ASSERT(dev.has_value(), "PDP_server_mmap_dev must be set!");

        std::string path = "/dev/" + dev.value();

        int fd = open(path.c_str(), O_RDWR);
        PDP_ASSERT(fd >= 0, "fail to open %s: %s", path.c_str(), strerror(errno));

        size = round_up(size, SZ_4K);
        void *addr = mmap(nullptr, size, PROT_READ | PROT_WRITE,
                MAP_SHARED, fd, 0);
        PDP_ASSERT(addr != MAP_FAILED, "fail to mmap");

        pr_info("memset 0, size=0x%lx", size);

        auto tp = std::chrono::steady_clock::now();
        for (uint64_t off = 0; off < size; off += SZ_1G) {
            uint8_t *iter_addr = (uint8_t *)addr + off;
            uint64_t iter_length = std::min<uint64_t>(size - off, SZ_1G);
            memset(iter_addr, 0, iter_length);
            msync(iter_addr, iter_length, MS_SYNC);
            pr_info("memset %lu GB.", off / SZ_1G);
        }
        auto d = std::chrono::steady_clock::now() - tp;
        pr_info("%.2lfs", std::chrono::duration<double>(d).count());
        madvise(addr, size, MADV_RANDOM);

        close(fd);

        return addr;

    }
}