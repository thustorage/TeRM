#pragma once

#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <fmt/format.h>
#include <chrono>
#include <optional>
#include <cstdint>
#include <cassert>


#ifndef SZ_1K
#define SZ_1K (1ul << 10)
#endif
#ifndef SZ_1M
#define SZ_1M (1ul << 20)
#endif
#ifndef SZ_1G
#define SZ_1G (1ul << 30) 
#endif

#define DYNAMIC_DEBUG       0

#define COLOR_BLACK         "\033[0;30m"
#define COLOR_RED           "\033[0;31m"
#define COLOR_GREEN         "\033[0;32m"
#define COLOR_YELLOW        "\033[0;33m"
#define COLOR_BLUE          "\033[0;34m"
#define COLOR_MAGENTA       "\033[0;35m"
#define COLOR_CYAN          "\033[0;36m"
#define COLOR_WHITE         "\033[0;37m"
#define COLOR_DEFAULT       "\033[0;39m"

#define COLOR_BOLD_BLACK    "\033[1;30m"
#define COLOR_BOLD_RED      "\033[1;31m"
#define COLOR_BOLD_GREEN    "\033[1;32m"
#define COLOR_BOLD_YELLOW   "\033[1;33m"
#define COLOR_BOLD_BLUE     "\033[1;34m"
#define COLOR_BOLD_MAGENTA  "\033[1;35m"
#define COLOR_BOLD_CYAN     "\033[1;36m"
#define COLOR_BOLD_WHITE    "\033[1;37m"
#define COLOR_BOLD_DEFAULT  "\033[1;39m"

#define PT_RESET            "\033[0m"
#define PT_BOLD             "\033[1m"
#define PT_UNDERLINE        "\033[4m"
#define PT_BLINKING         "\033[5m"
#define PT_INVERSE          "\033[7m"

#define LIBPDP_PREFIX COLOR_CYAN "[libpdp] " PT_RESET
#define pr_libpdp(fmt, args...) printf(LIBPDP_PREFIX fmt "\n", ##args)

#define EXTRACT_FILENAME(PATH) (__builtin_strrchr("/" PATH, '/') + 1)
#define __FILENAME__ EXTRACT_FILENAME(__FILE__)

#define pr(fmt, args...)  pr_libpdp(COLOR_GREEN "%s:%d: %s:" PT_RESET fmt, __FILENAME__, __LINE__, __func__, ##args)
#define pr_flf(file, line, func, fmt, args...) pr_libpdp(COLOR_GREEN "%s:%d: %s:" PT_RESET fmt, file, line, func, ##args)

#define pr_info(fmt, args...) pr(fmt, ##args)
#define pr_err(fmt, args...)  pr(COLOR_RED fmt PT_RESET, ##args)
#define pr_warn(fmt, args...) pr(COLOR_MAGENTA fmt PT_RESET, ##args)
#define pr_emph(fmt, args...) pr(COLOR_YELLOW fmt PT_RESET, ##args)
#if DYNAMIC_DEBUG
#define pr_debug(fmt, args...) ({ \
    static bool enable_debug = util::getenv_bool("ENABLE_DEBUG").value_or(false); \
    if (enable_debug) pr(fmt, ##args); \
})
#else
#define pr_debug(fmt, args...)
#endif

#define pr_once(level, format...)	({	\
	static bool __warned = false;			\
    if (!__warned) [[unlikely]] { pr_##level(format); 	\
    __warned = true;}		\
})

#define pr_coro(level, format, args...) pr_##level("coro_id=%d, " format, coro_id, ##args)

// #define ASSERT(...)
#define ASSERT(cond, format, args...)  ({ \
    if (!(cond)) [[unlikely]] { \
    pr_err(format, ##args); \
    exit(EXIT_FAILURE); \
    } \
})

#define ASSERT_PERROR(cond, format, args...) ASSERT(cond, "%s: " format, strerror(errno), ##args)

namespace term {
    using u64 = uint64_t;

    constexpr auto div_up(auto a, auto b)
    {
        return (a + b - 1) / b;
    }

    constexpr auto div_down(auto a, auto b)
    {
        return a / b;
    }

    constexpr auto round_up(auto a, auto b)
    {
        return div_up(a, b) * b;
    }

    constexpr auto round_down(auto a, auto b)
    {
        return div_down(a, b) * b;
    }

    static inline long long atoll_suffix(const char *str)
    {
        long long num = atoll(str);
        switch (str[strlen(str) - 1]) {
            case 'T':
            case 't':
                num *= 1024;
            case 'G':
            case 'g':
                num *= 1024;
            case 'M':
            case 'm':
                num *= 1024;
            case 'K':
            case 'k':
                num *= 1024;
        }
        return num;
    }

    static inline long long stoll_suffix(const std::string & str)
    {
        return atoll_suffix(str.c_str());
    }
    
    static inline std::optional<int> getenv_int(const char *env)
    {
        const char *v = getenv(env);
        if (!v) {
            return std::nullopt;
        }
        return std::stoi(v);
    }

    static inline std::optional<bool> getenv_bool(const char *env)
    {
        auto v = getenv_int(env);
        if (v.has_value()) {
            return v.value() != 0;
        }
        return {};
    }

    static inline bool is_server()
    {
        static bool flag = getenv_bool("PDP_is_server").value_or(false);
        return flag;
    }

    static inline uint64_t wall_time_ns()
    {
        struct timespec ts{};
        clock_gettime(CLOCK_REALTIME, &ts);
        return ts.tv_nsec + ts.tv_sec * 1'000'000'000;
    }

#if 0
    // define our own source location class, to manipulate the format.
    class SourceLocation {
        uint32_t line_;
        std::string function_name_;
        std::string file_name_;
    public:
        SourceLocation(const char *file_full_path = __builtin_FILE(), const uint32_t line = __builtin_LINE(), const char *function_name = __builtin_FUNCTION())
                : line_(line), function_name_(function_name)
        {
            std::string str{"/"};
            str += file_full_path;
            auto pos = str.find_last_of('/');
            file_name_ = str.substr(pos + 1);
        }

        static SourceLocation current(const char *file_full_path = __builtin_FILE(), const uint32_t line = __builtin_LINE(), const char *function_name = __builtin_FUNCTION())
        {
            return SourceLocation{file_full_path, line, function_name};
        }

        auto file_name() { return file_name_.c_str(); }
        auto line() { return line_; }
        auto function_name() { return function_name_.c_str(); }
    };
    class Recorder {
    public:
        using result_type = std::tuple<uint64_t, uint64_t, uint64_t>; // cnt, sum, avg
    protected:
        std::string name_;
        u64 sum_;
        u64 cnt_;
        u64 last_report_time_;
        u64 epoch_{};


        SourceLocation src_loc_;

        void record(uint64_t v)
        {
            sum_ += v;
            cnt_++;
        }

        std::tuple<uint64_t, uint64_t, uint64_t> tick()
        {
            u64 avg = cnt_ ? sum_ / cnt_ : 0;
            return std::make_tuple(cnt_, sum_, avg);
        }

        void print(const result_type &value, u64 duration)
        {
            double duration_seconds = double(duration) / 1e9;
            pr_flf(src_loc_.file_name(), src_loc_.line(), src_loc_.function_name(), "%s",
                    fmt::format(std::locale(""), "{}[epoch {}, {:.2f}s], cnt={:L}, sum={:L}, avg={:L}", 
                        name_, epoch_++, duration_seconds,
                        std::get<0>(value),
                        std::get<1>(value), (std::get<1>(value)) / std::get<0>(value)).c_str());
        }

        void clear()
        {
            sum_ = 0;
            cnt_ = 0;
        }

        bool should_tick(uint64_t current_time_ns = wall_time_ns(), u64 *time_span = nullptr)
        {
            if (current_time_ns - last_report_time_ > 1'000'000'000) {
                bool flag = (last_report_time_ == 0);
                if (time_span) {
                    *time_span = current_time_ns - last_report_time_;
                }
                last_report_time_ = current_time_ns;
                if (flag) return false;

                return true;
            }
            return false;
        }
    public:
        explicit Recorder(std::string name, SourceLocation src_loc = SourceLocation::current())
            : name_(std::move(name)),
                src_loc_(std::move(src_loc))
        {}

        virtual ~Recorder() = default;

        void record_one(uint64_t v)
        {
            record(v);
            u64 tp = wall_time_ns();
            if (should_tick(tp)) {
                auto r = tick();
                print(r, 0);
                clear();
            }
        }
    };

    class LatencyRecorder : public Recorder {
    private:
        uint64_t ts_begin_;

    public:
        LatencyRecorder(const std::string &name, SourceLocation src_loc = SourceLocation::current())
            : Recorder(name, std::move(src_loc)) {}

        void begin_one()
        {
            ts_begin_ = wall_time_ns();
        }

        void end_one()
        {
            auto current_time_ns = wall_time_ns();
            auto latency_ns = current_time_ns - ts_begin_;
            u64 duration;
            record(latency_ns);
            if (should_tick(current_time_ns, &duration)) {
                auto r = tick();
                print(r, duration);
                clear();
                return;
            }
            return;
        }
    };

    template <typename T>
    class LatencyRecorderHelper {
        T &lr_;
    public:
        LatencyRecorderHelper(T &lr) : lr_(lr)
        {
            lr_.begin_one();
        }
        ~LatencyRecorderHelper()
        {
            lr_.end_one();
        }
    };
#endif
    class ZipfGen {
    private:
        struct zipf_gen_state {
            uint64_t n;      // number of items (input)
            double theta;    // skewness (input) in (0, 1); or, 0 = uniform, 1 = always
            // zero
            double alpha;    // only depends on theta
            double thres;    // only depends on theta
            uint64_t last_n; // last n used to calculate the following
            double dbl_n;
            double zetan;
            double eta;
            // unsigned short rand_state[3];		// prng state
            uint64_t rand_state;
        };
        struct zipf_gen_state state_;

        static double mehcached_rand_d(uint64_t *state) {
            // caution: this is maybe too non-random
            *state = (*state * 0x5deece66dUL + 0xbUL) & ((1UL << 48) - 1);
            return (double) *state / (double) ((1UL << 48) - 1);
        }

        static double mehcached_pow_approx(double a, double b) {
            // from
            // http://martin.ankerl.com/2012/01/25/optimized-approximative-pow-in-c-and-cpp/

            // calculate approximation with fraction of the exponent
            int e = (int) b;
            union {
                double d;
                int x[2];
            } u = {a};
            u.x[1] =
                    (int) ((b - (double) e) * (double) (u.x[1] - 1072632447) + 1072632447.);
            u.x[0] = 0;

            // exponentiation by squaring with the exponent's integer part
            // double r = u.d makes everything much slower, not sure why
            // TODO: use popcount?
            double r = 1.;
            while (e) {
                if (e & 1)
                    r *= a;
                a *= a;
                e >>= 1;
            }

            return r * u.d;
        }

        static void mehcached_zipf_init(struct zipf_gen_state *state, uint64_t n,
                                        double theta, uint64_t rand_seed) {
            assert(n > 0);
            if (theta > 0.992 && theta < 1)
                fprintf(stderr,
                        "theta > 0.992 will be inaccurate due to approximation\n");
            if (theta >= 1. && theta < 40.) {
                fprintf(stderr, "theta in [1., 40.) is not supported\n");
                assert(false);
            }
            assert(theta == -1. || (theta >= 0. && theta < 1.) || theta >= 40.);
            assert(rand_seed < (1UL << 48));
            memset(state, 0, sizeof(struct zipf_gen_state));
            state->n = n;
            state->theta = theta;
            if (theta == -1.)
                rand_seed = rand_seed % n;
            else if (theta > 0. && theta < 1.) {
                state->alpha = 1. / (1. - theta);
                state->thres = 1. + mehcached_pow_approx(0.5, theta);
            } else {
                state->alpha = 0.; // unused
                state->thres = 0.; // unused
            }
            state->last_n = 0;
            state->zetan = 0.;
            // state->rand_state[0] = (unsigned short)(rand_seed >> 0);
            // state->rand_state[1] = (unsigned short)(rand_seed >> 16);
            // state->rand_state[2] = (unsigned short)(rand_seed >> 32);
            state->rand_state = rand_seed;
        }

        static void mehcached_zipf_init_copy(struct zipf_gen_state *state,
                                            const struct zipf_gen_state *src_state,
                                            uint64_t rand_seed) {

            (void) mehcached_zipf_init_copy;
            assert(rand_seed < (1UL << 48));
            memcpy(state, src_state, sizeof(struct zipf_gen_state));
            // state->rand_state[0] = (unsigned short)(rand_seed >> 0);
            // state->rand_state[1] = (unsigned short)(rand_seed >> 16);
            // state->rand_state[2] = (unsigned short)(rand_seed >> 32);
            state->rand_state = rand_seed;
        }

        static void mehcached_zipf_change_n(struct zipf_gen_state *state, uint64_t n) {
            (void) mehcached_zipf_change_n;
            state->n = n;
        }

        static double mehcached_zeta(uint64_t last_n, double last_sum, uint64_t n,
                                    double theta) {
            if (last_n > n) {
                last_n = 0;
                last_sum = 0.;
            }
            while (last_n < n) {
                last_sum += 1. / mehcached_pow_approx((double) last_n + 1., theta);
                last_n++;
            }
            return last_sum;
        }

        static uint64_t mehcached_zipf_next(struct zipf_gen_state *state) {
            if (state->last_n != state->n) {
                if (state->theta > 0. && state->theta < 1.) {
                    state->zetan = mehcached_zeta(state->last_n, state->zetan, state->n,
                                                state->theta);
                    state->eta =
                            (1. - mehcached_pow_approx(2. / (double) state->n,
                                                    1. - state->theta)) /
                            (1. - mehcached_zeta(0, 0., 2, state->theta) / state->zetan);
                }
                state->last_n = state->n;
                state->dbl_n = (double) state->n;
            }

            if (state->theta == -1.) {
                uint64_t v = state->rand_state;
                if (++state->rand_state >= state->n)
                    state->rand_state = 0;
                return v;
            } else if (state->theta == 0.) {
                double u = mehcached_rand_d(&state->rand_state);
                return (uint64_t) (state->dbl_n * u);
            } else if (state->theta >= 40.) {
                return 0UL;
            } else {
                // from J. Gray et al. Quickly generating billion-record synthetic
                // databases. In SIGMOD, 1994.

                // double u = erand48(state->rand_state);
                double u = mehcached_rand_d(&state->rand_state);
                double uz = u * state->zetan;
                if (uz < 1.)
                    return 0UL;
                else if (uz < state->thres)
                    return 1UL;
                else
                    return (uint64_t) (
                            state->dbl_n *
                            mehcached_pow_approx(state->eta * (u - 1.) + 1., state->alpha));
            }
        }

    public:
        ZipfGen(uint64_t n, double theta, uint64_t rand_seed)
        {
            mehcached_zipf_init(&state_, n, theta, rand_seed);
        }

        uint64_t next()
        {
            return mehcached_zipf_next(&state_);
        }
    };

    using u64 = uint64_t;
    static inline u64 hash_u64(u64 val) {
        const u64 kFNVOffsetBasis64 = 0xCBF29CE484222325;
        const u64 kFNVPrime64       = 1099511628211;
        u64 hash = kFNVOffsetBasis64;

        for (int i = 0; i < 8; i++) {
            u64 octet = val & 0x00ff;
            val = val >> 8;

            hash = hash ^ octet;
            hash = hash * kFNVPrime64;
        }
        return hash;
    }

    static inline void *alloc(uint64_t size)
    {
        size = round_up(size, SZ_1G);
        pr_info("%lu GB", size / SZ_1G);
        int fd = open("/dev/nvme4n1", O_RDWR);
        ASSERT_PERROR(fd >= 0, "failed to open nvme4n1.");

        void *addr = mmap(nullptr, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
        ASSERT_PERROR(addr != MAP_FAILED, "failed to mmap nvme4n1");
        
        pr_info("memset 0, size=0x%lx", size);

        auto tp = std::chrono::steady_clock::now();
        for (uint64_t off = 0; off < size; off += SZ_1G) {
            uint8_t *iter_addr = (uint8_t *)addr + off;
            uint64_t iter_length = std::min<uint64_t>(size - off, SZ_1G);
            memset(iter_addr, 0, iter_length);
            msync(iter_addr, iter_length, MS_SYNC);
            pr_info("memset %lu GB.", off / SZ_1G);
        }
        auto d = std::chrono::steady_clock::now() - tp;

        pr_info("%.2lfs", std::chrono::duration<double>(d).count());

        madvise(addr, size, MADV_RANDOM);

        return addr;
    }
}
