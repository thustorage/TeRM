#!/bin/bash
rm -rf /mnt/huge/*
