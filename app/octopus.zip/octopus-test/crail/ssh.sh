#!/bin/bash
ssh -t -p 22 10.0.2.83 "rm -rf /mnt/huge/*"
