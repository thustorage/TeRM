cd /home/yz/workspace/3-nic-odp/octopus-origin/build
# cmake .. -DCMAKE_BUILD_TYPE=Release
# cmake .. -DCMAKE_BUILD_TYPE=Debug
# rm -rf *
cmake ..

make -j
