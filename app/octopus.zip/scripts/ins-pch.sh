#!/bin/bash
cd /home/yz/workspace/3-nic-odp/nic-odp/kmod
make
rmmod pch
insmod pch.ko
