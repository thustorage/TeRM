#ifndef __USE_FILE_OFFSET64
#define __USE_FILE_OFFSET64
#endif
#define TEST_NRFS_IO
// #define TEST_RAW_IO
#include "mpi.h"
#include "nrfs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "libterm.hh"

#include <gflags/gflags.h>
#include <thread>

#define BUFFER_SIZE (128UL << 10)
int myid, file_seq;
int numprocs;
nrfs fs;
char buf[BUFFER_SIZE];
int mask = 0;

DEFINE_bool(write, false, "write");
DEFINE_string(file_size, "2G", "file size");
DEFINE_string(unit_size, "4k", "unit size");
DEFINE_uint64(seconds, 60, "running seconds");
DEFINE_double(zipf_theta, 0.99, "zipfian theta");

#define SZ_1K (1ul << 10)
#define SZ_4K (4ul << 10)
#define SZ_1M (1ul << 20)
#define SZ_1G (1ul << 30)

static int collect_time(int cost)
{
	int i;
	char message[8];
	MPI_Status status;
	int *p = (int*)message;
	int max = cost;
	for(i = 1; i < numprocs; i++)
	{
		MPI_Recv(message, 8, MPI_CHAR, i, 99, MPI_COMM_WORLD, &status);
		if(*p > max)
			max = *p;
	}
	return max;
}

static void create_fill_file(int file_id, uint64_t file_size)
{
	char path[255];

	uint64_t unit_size = 64 * SZ_1K;
	file_size = term::round_up(file_size, unit_size);

	/* file open */
	sprintf(path, "/file_%d", file_id);
	nrfsOpenFile(fs, path, O_CREAT);
	printf("create file: %s\n", path);
	// memset(buf, 'a', BUFFER_SIZE);

	for(uint64_t offset = 0; offset < file_size; offset += unit_size)
	{
		if (offset % SZ_1G == 0) {
			pr_info("%lu GB", offset / SZ_1G);
		}
		nrfsWriteFake(fs, path, buf, 64 * SZ_1K, offset);
	}
	// end = MPI_Wtime();

	// MPI_Barrier ( MPI_COMM_WORLD );

	// *p = (int)((end - start) * 1000000);

	// if(myid != 0)
	// {
	// 	MPI_Send(message, 8, MPI_CHAR, 0, 99, MPI_COMM_WORLD);
	// }
	// else
	// {
	// 	time_cost = collect_time(*p);
	// 	num = (double)((uint64_t)size * op_time * numprocs) / time_cost;
	// 	rate = 1000000 * num / 1024 / 1024;
	// 	printf("Write Bandwidth = %f MB/s TimeCost = %d\n", rate, (int)time_cost);
	// }
	nrfsCloseFile(fs, path);

	// file_seq += 1;
	// if(file_seq == numprocs)
	// 	file_seq = 0;
}

static void write_test(int file_id, uint64_t file_size, uint64_t unit_size, uint64_t seconds, uint64_t *count)
{
	char path[255];
	double start, end, rate, num;
	int time_cost;
	char message[8];
	int *p = (int*)message;
	uint64_t nr_ops = 0;


	pr_info("========= write test file %d =========", file_id);
	/* file open */
	sprintf(path, "/file_%d", file_id);
	nrfsOpenFile(fs, path, O_CREAT);
	printf("create file: %s\n", path);
	memset(buf, 'a', BUFFER_SIZE);

	MPI_Barrier ( MPI_COMM_WORLD );
	
	start = MPI_Wtime();
	
	uint64_t nr_units = file_size / unit_size;
	term::ZipfGen zipf_gen(nr_units, FLAGS_zipf_theta, file_id);

	auto tp = std::chrono::steady_clock::now();
	for(uint64_t i = 0; ; i++)
	{
		uint64_t v = zipf_gen.next();
		v = term::hash_u64(v) % nr_units;
		uint64_t offset = unit_size * v;
		nrfsWrite(fs, path, buf, unit_size, offset);
		(*count)++;
		nr_ops++;
		if (std::chrono::steady_clock::now() - tp > std::chrono::seconds{seconds}) {
			break;
		}
	}
	end = MPI_Wtime(); // seconds

	MPI_Barrier ( MPI_COMM_WORLD );

	*p = (int)((end - start) * 1'000'000); // seconds * 1'000'000 => micro seconds

	if(myid != 0)
	{
		MPI_Send(message, 8, MPI_CHAR, 0, 99, MPI_COMM_WORLD);
	}
	else
	{
		time_cost = collect_time(*p);
		num = (double)unit_size * nr_ops * numprocs / time_cost;
		rate = 1'000'000 * num / 1024 / 1024;
		printf("Write Bandwidth = %f MB/s TimeCost = %d\n", rate, (int)time_cost);
	}
	nrfsCloseFile(fs, path);

	// file_seq += 1;
	// if(file_seq == numprocs)
	// 	file_seq = 0;
}

static void read_test(int file_id, uint64_t file_size, uint64_t unit_size, uint64_t seconds, uint64_t *count)
{
	char path[255];
	double start, end, rate, num;
	int time_cost;
	char message[8];
	int *p = (int*)message;
	uint64_t nr_ops = 0;
	pr_info("========= read test file %d =========", file_id);

	/* file open */
	sprintf(path, "/file_%d", file_id);
	nrfsOpenFile(fs, path, O_CREAT);
	printf("create file: %s\n", path);
	memset(buf, 'a', BUFFER_SIZE);

	MPI_Barrier ( MPI_COMM_WORLD );
	
	start = MPI_Wtime(); // do not comment this line. leave it here to make octopus happy.
	
	uint64_t nr_units = file_size / unit_size;
	term::ZipfGen zipf_gen(nr_units, FLAGS_zipf_theta, file_id);

	auto tp = std::chrono::steady_clock::now();
	for(uint64_t i = 0; ; i++)
	{
		uint64_t v = zipf_gen.next();
		v = term::hash_u64(v) % nr_units;
		uint64_t offset = unit_size * v;
		nrfsRead(fs, path, buf, unit_size, offset);
		(*count)++;
		nr_ops++;
		if (std::chrono::steady_clock::now() - tp > std::chrono::seconds{seconds}) {
			break;
		}
	}
	end = MPI_Wtime(); // seconds

	MPI_Barrier ( MPI_COMM_WORLD );

	*p = (int)((end - start) * 1000000); // seconds * 1'000'000 => micro seconds

	if(myid != 0)
	{
		MPI_Send(message, 8, MPI_CHAR, 0, 99, MPI_COMM_WORLD);
	}
	else
	{
		time_cost = collect_time(*p);
		num = (double)unit_size * nr_ops * numprocs / time_cost;
		rate = 1000000 * num / 1024 / 1024;
		printf("Read Bandwidth = %f MB/s TimeCost = %d\n", rate, (int)time_cost);
	}
	nrfsCloseFile(fs, path);

	// file_seq += 1;
	// if(file_seq == numprocs)
	// 	file_seq = 0;
}

void print_thpt_func(const std::stop_token &stop_token, int mpi_rank, uint64_t *count)
{
	int epoch = 0;
	uint64_t last_count = 0;
	while (!stop_token.stop_requested()) {
		auto tp = std::chrono::steady_clock::now();
		pr_emph("[%d] epoch %d: %lu", mpi_rank, epoch++, *count - last_count);
		last_count = *count;
		std::this_thread::sleep_until(tp + std::chrono::seconds{1});
	}
}

int main(int argc, char **argv)
{
    gflags::SetUsageMessage(argv[0]);
    gflags::ParseCommandLineFlags(&argc, &argv, true);

	MPI_Init( &argc, &argv);
	MPI_Comm_rank( MPI_COMM_WORLD, &myid );
	MPI_Comm_size( MPI_COMM_WORLD, &numprocs );
	file_seq = myid;
	MPI_Barrier ( MPI_COMM_WORLD );

	/* nrfs connection */
	fs = nrfsConnect("default", 0, 0);

	MPI_Barrier ( MPI_COMM_WORLD );

	uint64_t file_size = term::stoll_suffix(FLAGS_file_size);
	uint64_t unit_size = term::stoll_suffix(FLAGS_unit_size);
	pr_info("file_size=0x%lx, unit_size=0x%lx", file_size, unit_size);
	for (int i = 0; i < numprocs; i++) {
		// printf("[%d] for file %d\n", myid, i);
		if (myid == i) {
			// filling file
			printf("[%d] filling file %d\n", myid, i);
			create_fill_file(myid, file_size);
		}
		MPI_Barrier(MPI_COMM_WORLD);
	}

	uint64_t count = 0;
	std::jthread print_thpt_thread([&count](const std::stop_token &stop_token) {
		print_thpt_func(stop_token, myid, &count);
	});
	if (FLAGS_write) {
		write_test(myid, file_size, unit_size, FLAGS_seconds, &count);
	} else {
		read_test(myid, file_size, unit_size, FLAGS_seconds, &count);
	}

	MPI_Barrier ( MPI_COMM_WORLD );
	char path[256];
	sprintf(path, "/file_%d", myid);
	nrfsDelete(fs, path);
	nrfsDisconnect(fs);

	MPI_Finalize();
}
