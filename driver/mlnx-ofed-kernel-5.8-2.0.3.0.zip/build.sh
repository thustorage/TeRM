is_conf_set() {
	grep -q "^$1=[ym]" "$kernel_source_dir/.config" 2>/dev/null
}
STRIP_MODS=${STRIP_MODS:-yes}
kernelver=${kernelver:-$(uname -r)}
kernel_source_dir=${kernel_source_dir:-/lib/modules/$kernelver/build}
i=0
BUILT_MODULE_NAME[$i]=mlx_compat
BUILT_MODULE_LOCATION[$i]=compat
DEST_MODULE_NAME[$i]=mlx_compat
DEST_MODULE_LOCATION[$i]=/kernel/compat
STRIP[$i]="$STRIP_MODS"
let i++
BUILT_MODULE_NAME[$i]=ib_core
BUILT_MODULE_LOCATION[$i]=drivers/infiniband/core
DEST_MODULE_NAME[$i]=ib_core
DEST_MODULE_LOCATION[$i]=/kernel/drivers/infiniband/core
STRIP[$i]="$STRIP_MODS"
let i++
BUILT_MODULE_NAME[$i]=ib_cm
BUILT_MODULE_LOCATION[$i]=drivers/infiniband/core
DEST_MODULE_NAME[$i]=ib_cm
DEST_MODULE_LOCATION[$i]=/kernel/drivers/infiniband/core
STRIP[$i]="$STRIP_MODS"
let i++
BUILT_MODULE_NAME[$i]=iw_cm
BUILT_MODULE_LOCATION[$i]=drivers/infiniband/core
DEST_MODULE_NAME[$i]=iw_cm
DEST_MODULE_LOCATION[$i]=/kernel/drivers/infiniband/core
STRIP[$i]="$STRIP_MODS"
let i++
BUILT_MODULE_NAME[$i]=ib_umad
BUILT_MODULE_LOCATION[$i]=drivers/infiniband/core
DEST_MODULE_NAME[$i]=ib_umad
DEST_MODULE_LOCATION[$i]=/kernel/drivers/infiniband/core
STRIP[$i]="$STRIP_MODS"
let i++
BUILT_MODULE_NAME[$i]=ib_uverbs
BUILT_MODULE_LOCATION[$i]=drivers/infiniband/core
DEST_MODULE_NAME[$i]=ib_uverbs
DEST_MODULE_LOCATION[$i]=/kernel/drivers/infiniband/core
STRIP[$i]="$STRIP_MODS"
let i++
BUILT_MODULE_NAME[$i]=rdma_cm
BUILT_MODULE_LOCATION[$i]=drivers/infiniband/core
DEST_MODULE_NAME[$i]=rdma_cm
DEST_MODULE_LOCATION[$i]=/kernel/drivers/infiniband/core
STRIP[$i]="$STRIP_MODS"
let i++
BUILT_MODULE_NAME[$i]=rdma_ucm
BUILT_MODULE_LOCATION[$i]=drivers/infiniband/core
DEST_MODULE_NAME[$i]=rdma_ucm
DEST_MODULE_LOCATION[$i]=/kernel/drivers/infiniband/core
STRIP[$i]="$STRIP_MODS"
let i++
BUILT_MODULE_NAME[$i]=mlxfw
BUILT_MODULE_LOCATION[$i]=drivers/net/ethernet/mellanox/mlxfw
DEST_MODULE_NAME[$i]=mlxfw
DEST_MODULE_LOCATION[$i]=/kernel/drivers/net/ethernet/mellanox/mlxfw
STRIP[$i]="$STRIP_MODS"
let i++
BUILT_MODULE_NAME[$i]=mlx5_core
BUILT_MODULE_LOCATION[$i]=drivers/net/ethernet/mellanox/mlx5/core
DEST_MODULE_NAME[$i]=mlx5_core
DEST_MODULE_LOCATION[$i]=/kernel/drivers/net/ethernet/mellanox/mlx5/core
STRIP[$i]="$STRIP_MODS"
let i++
BUILT_MODULE_NAME[$i]=mlx5_ib
BUILT_MODULE_LOCATION[$i]=drivers/infiniband/hw/mlx5
DEST_MODULE_NAME[$i]=mlx5_ib
DEST_MODULE_LOCATION[$i]=/kernel/drivers/infiniband/hw/mlx5
STRIP[$i]="$STRIP_MODS"
let i++
BUILT_MODULE_NAME[$i]=ib_ipoib
BUILT_MODULE_LOCATION[$i]=drivers/infiniband/ulp/ipoib
DEST_MODULE_NAME[$i]=ib_ipoib
DEST_MODULE_LOCATION[$i]=/kernel/drivers/infiniband/ulp/ipoib
STRIP[$i]="$STRIP_MODS"
let i++
if [[ $(VER $kernelver) < $(VER '5.11.0') ]]; then
BUILT_MODULE_NAME[$i]=auxiliary
BUILT_MODULE_LOCATION[$i]=drivers/base
DEST_MODULE_NAME[$i]=auxiliary
DEST_MODULE_LOCATION[$i]=/kernel/drivers/base
STRIP[$i]="$STRIP_MODS"
let i++
fi
if [[ ! $(VER $kernelver) < $(VER '4.15.0') ]]; then
BUILT_MODULE_NAME[$i]=mlxdevm
BUILT_MODULE_LOCATION[$i]=net/mlxdevm
DEST_MODULE_NAME[$i]=mlxdevm
DEST_MODULE_LOCATION[$i]=/kernel/net/mlxdevm
STRIP[$i]="$STRIP_MODS"
let i++
fi
if is_conf_set CONFIG_INFINIBAND_IRDMA; then
BUILT_MODULE_NAME[$i]=irdma
BUILT_MODULE_LOCATION[$i]=drivers/infiniband/hw/irdma
DEST_MODULE_NAME[$i]=irdma
DEST_MODULE_LOCATION[$i]=/kernel/drivers/infiniband/hw/irdma
STRIP[$i]="$STRIP_MODS"
let i++
fi
#:# ExtraOption --with-mlx5-ipsec
#:# ExtraOption --with-gds
MAKE="./ofed_scripts/pre_build.sh $kernelver $kernel_source_dir mlnx-ofed-kernel 5.8"
CLEAN="make clean"
PACKAGE_NAME=mlnx-ofed-kernel
PACKAGE_VERSION=5.8
REMAKE_INITRD=yes
AUTOINSTALL=yes
POST_INSTALL="ofed_scripts/dkms_build_ulps.sh $kernelver"

$MAKE
